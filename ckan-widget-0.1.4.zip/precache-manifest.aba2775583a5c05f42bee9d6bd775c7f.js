self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b6990410bd391dfed6977b02876a128a",
    "url": "./index.html"
  },
  {
    "revision": "83f5558bc4e8f666b38e",
    "url": "./static/css/main.6a144f42.chunk.css"
  },
  {
    "revision": "f5670a7c8afced5c9fe5",
    "url": "./static/js/2.0f353ecd.chunk.js"
  },
  {
    "revision": "83f5558bc4e8f666b38e",
    "url": "./static/js/main.4ec58531.chunk.js"
  },
  {
    "revision": "18c578c871504ee60207",
    "url": "./static/js/runtime-main.60db20b2.js"
  }
]);